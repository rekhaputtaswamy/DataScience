# LogisticRegression_Vectorized_Implementation

Concepts are inspired from Prof. Andrew Ng's machine learning course and Siraj Raval's Videos.
